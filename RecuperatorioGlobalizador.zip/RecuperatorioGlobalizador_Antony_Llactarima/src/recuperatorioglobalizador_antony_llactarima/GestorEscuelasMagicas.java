/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatorioglobalizador_antony_llactarima;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anton
 * @param <T>
 */
public class GestorEscuelasMagicas<T extends EscuelaMagica> {
    
    private List<T> escuelasMagicas;
    
    public GestorEscuelasMagicas(){
        escuelasMagicas = new ArrayList<>();
    }
    
    public void registrarEscuela(T nuevaEscuela){
        for(T e : escuelasMagicas){
            if(e.equals(nuevaEscuela)){
                throw new EscuelaRepetidaException();
            }else{
                escuelasMagicas.add(nuevaEscuela);
            }
        }
    }
    
}
