/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatorioglobalizador_antony_llactarima;

import java.util.Date;

/**
 *
 * @author anton
 */
public class TorneoHechizeria {
    private String nombre;
    private Date fechaRealizacion;
    private int MAX_PARTICIPANTES;
    private EstadoTorneo estadoTorneo;
    
    public TorneoHechizeria(String nombre, Date fechaInicio,int maxParticipantes, EstadoTorneo estadoTorneo){
        this.nombre = nombre;
        this.fechaRealizacion = fechaInicio;
        this.MAX_PARTICIPANTES = maxParticipantes;
        this.estadoTorneo = estadoTorneo;
    }
    
}
