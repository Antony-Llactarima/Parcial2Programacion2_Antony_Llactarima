
package recuperatorioglobalizador_antony_llactarima;


public class Principal {

    public static void main(String[] args) {
        EscuelaMagica InsInv1 = new InstitutoInvocacion("jkjkjk", 2000, "Bosque");
        EscuelaMagica InsInv2 = new InstitutoInvocacion("lololo", 1200, "Montaña");
        EscuelaMagica AcaEnc1 = new AcademiaEncantamientos("popopo", 90, "Cielo");
        EscuelaMagica AcaEnc2 = new AcademiaEncantamientos("jojojo", 2024, "Playa");
        EscuelaMagica HecElem1 = new EscuelaHechizosElementales("gagaga", 300, "Luna");
        EscuelaMagica HecElem2 = new EscuelaHechizosElementales("zazaza", 470, "Volcan");
        
        GestorEscuelasMagicas gestorMain = new GestorEscuelasMagicas();
        agregarEscuela(InsInv1, gestorMain);
        agregarEscuela(InsInv1, gestorMain);
        agregarEscuela(InsInv2, gestorMain);
        agregarEscuela(AcaEnc1, gestorMain);
        agregarEscuela(AcaEnc2, gestorMain);
        agregarEscuela(HecElem1, gestorMain);
        agregarEscuela(HecElem2, gestorMain);
    }
    
    public static void agregarEscuela(EscuelaMagica escNueva, GestorEscuelasMagicas gestor){
        try{
            gestor.registrarEscuela(escNueva);
        }catch(EscuelaRepetidaException ex){
            System.out.println(ex.getMessage());
        }
    }
    
}
