/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatorioglobalizador_antony_llactarima;

/**
 *
 * @author anton
 */
public class TorneoRepetidoException extends RuntimeException{
    private static String MESSAGE = "Torneo ingresada esta repetida.";
    
    public TorneoRepetidoException(){
        super(MESSAGE);
    }
}
