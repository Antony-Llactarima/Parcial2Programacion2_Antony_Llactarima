
package recuperatorioglobalizador_antony_llactarima;

import java.util.ArrayList;
import java.util.List;


public abstract class EscuelaMagica {
    private String nombre;
    private int anioFundacion;
    private String ubicacion;
    private List<TorneoHechizeria> torneosMagicos = new ArrayList<>();
    
    public EscuelaMagica(String nombre,int anioInicio,String ubicacion){
        this.nombre = nombre;
        this.anioFundacion = anioInicio;
        this.ubicacion = ubicacion;
    }
    
    public void crearEncantamiento(){
        System.out.println("Esta escuela no puede crear encantamientos.");
    }
    
    public void registrarTorneo(TorneoHechizeria torneoNuevo){
        torneosMagicos.add(torneoNuevo);
    }
    
    
    
    @Override
    public String toString(){
        return nombre+ " - "+ anioFundacion+ " - "+ ubicacion;
    }
        
    
}
